import React, { useState, useEffect, useRef } from 'react';
import io from 'socket.io-client';
import styled from 'styled-components';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCircle, faPaperPlane, faUserCircle, faSearch, faEdit, faTrash } from '@fortawesome/free-solid-svg-icons';
import { PulseLoader } from 'react-spinners';

// Initialize socket connection
const socket = io('http://localhost:5000');

// Styled components
const Container = styled.div`
  display: flex;
  height: 100vh;
  background-color: #f5f5f5;
`;

const UserListContainer = styled.div`
  width: 30%;
  background-color: #fff;
  padding: 10px;
  border-right: 1px solid #ccc;
  overflow-y: auto;
`;

const UserName = styled.div`
  padding: 15px;
  font-weight: bold;
  text-align: center;
  background-color: #f8f8f8;
  border-bottom: 1px solid #ccc;
  font-size: 18px;
`;

const SearchContainer = styled.div`
  padding: 10px;
  border-bottom: 1px solid #ccc;
  display: flex;
  align-items: center;
`;

const SearchInput = styled.input`
  width: 100%;
  padding: 8px 12px;
  border: 1px solid #ccc;
  border-radius: 20px;
  font-size: 14px;
  outline: none;
  padding-left: 40px;
  position: relative;
`;

const ChatWindow = styled.div`
  width: 70%;
  display: flex;
  flex-direction: column;
  background-color: #f9f9f9;
`;

const SelectedUserInfo = styled.div`
  padding: 10px;
  background-color: #f1f1f1;
  border-bottom: 1px solid #ddd;
  text-align: left;
  font-size: 16px;
  font-weight: bold;
`;

const MessageContainer = styled.div`
  flex-grow: 1;
  padding: 20px;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  background-color: #e5e5e5;
`;

const Message = styled.div`
  margin: 15px 0;
  padding: 10px 15px;
  border-radius: 20px;
  background-color: ${({ $isSender }) => ($isSender ? '#DCF8C6' : '#fff')};
  align-self: ${({ $isSender }) => ($isSender ? 'flex-end' : 'flex-start')};
  max-width: 60%;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
  font-family: 'Arial', sans-serif;
  position: relative;
`;

const Timestamp = styled.small`
  position: absolute;
  right: 10px;
  bottom: -20px;
  font-size: 12px;
  color: blue;
  font-weight: bolder;
`;

const ActionButtons = styled.div`
  display: flex;
  gap: 10px;
  position: relative;
  top: 5px;
  right: 100px;
`;

const TypingIndicator = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 5px 0;
`;

const InputContainer = styled.div`
  display: flex;
  padding: 10px;
  background-color: #fff;
  border-top: 1px solid #ccc;
`;

const Input = styled.input`
  flex-grow: 1;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 20px;
  font-size: 16px;
  outline: none;
  padding-left: 20px;
`;

const Button = styled.button`
  padding: 10px 20px;
  margin-left: 10px;
  background-color: #25D366;
  color: white;
  border: none;
  border-radius: 20px;
  cursor: pointer;
  display: flex;
  align-items: center;
  font-size: 16px;
  transition: background-color 0.3s ease;

  &:hover {
    background-color: #128c7e;
  }
`;

const FileInput = styled.input`
  margin-left: 10px;
  cursor: pointer;
`;

const StatusIndicator = styled(FontAwesomeIcon)`
  margin-right: 10px;
  color: ${({ status }) => (status === 'online' ? 'green' : 'gray')};
`;

function App() {
  const [username, setUsername] = useState('');
  const [loggedInUser, setLoggedInUser] = useState(null);
  const [userList, setUserList] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState([]);
  const [selectedUser, setSelectedUser] = useState(null);
  const [selectedUserEmail, setSelectedUserEmail] = useState(null);
  const [isTyping, setIsTyping] = useState(false);

  const typingTimeout = useRef();
  const messagesEndRef = useRef(null);

  // Event listeners setup
  useEffect(() => {
    const handleReceiveMessage = (data) => {
      // Only append messages that are from or to the selected user
      if (
        (data.sender === selectedUser && data.receiver === loggedInUser) ||
        (data.sender === loggedInUser && data.receiver === selectedUser)
      ) {
        setMessages((prevMessages) => [...prevMessages, data]);
      }
    };

    socket.on('receiveMessage', handleReceiveMessage);

    return () => {
      socket.off('receiveMessage', handleReceiveMessage);
    };
  }, [loggedInUser, selectedUser]);

  useEffect(() => {
    socket.on('updateUserList', (data) => setUserList(data));

    socket.on('userExists', (exists) => {
      if (!exists) {
        alert('Username does not exist');
        setLoggedInUser(null);
      }
    });

    socket.on('userTyping', (user) => user === selectedUser && setIsTyping(true));

    socket.on('stopTyping', (user) => user === selectedUser && setIsTyping(false));

    return () => {
      socket.off('updateUserList');
      socket.off('userExists');
      socket.off('userTyping');
      socket.off('stopTyping');
    };
  }, [loggedInUser, selectedUser]);

  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isTyping]);

  useEffect(() => {
    if (selectedUser) {
      // Remove any previous listener to avoid multiple listeners being attached
      socket.off('chatHistory');
  
      // Listen for the chat history
      socket.on('chatHistory', (chatHistory) => {
        setMessages(chatHistory);
      });
  
      // Cleanup the listener when the component is unmounted or selectedUser changes
      return () => {
        socket.off('chatHistory');
      };
    }
  }, [selectedUser]); // Re-run this effect when `selectedUser` changes
  

  const handleLogin = () => {
    if (username.trim()) {
      socket.emit('checkUser', username);
      setLoggedInUser(username);
    }
  };

  const handleUserSelect = (user) => {
    setSelectedUser(user.username);
    setSelectedUserEmail(user.email);
    setMessages([]); // Clear previous messages
  
    // Emit the event to fetch chat history
    socket.emit('getChatHistory', { sender: loggedInUser, receiver: user.username });
  };
  
  const sendMessage = () => {
    if (selectedUser && message.trim()) {
      const chatTime = new Date().toTimeString().slice(0, 5);

      const messageData = {
        sender: loggedInUser,
        receiver: selectedUser,
        message: message.trim(),
        chat_time: chatTime,
      };

      // Append the message locally for the sender
      setMessages((prevMessages) => [...prevMessages, messageData]);

      // Send the message to the server
      socket.emit('sendMessage', messageData);

      // Clear the message input field after sending
      setMessage('');
    }
  };

  const handleTyping = () => {
    if (selectedUser) {
      socket.emit('typing', { to: selectedUser, from: loggedInUser });

      if (typingTimeout.current) {
        clearTimeout(typingTimeout.current);
      }

      typingTimeout.current = setTimeout(() => {
        socket.emit('stopTyping', { to: selectedUser, from: loggedInUser });
      }, 1000);
    }
  };

  const handleFileUpload = (e) => {
    const file = e.target.files[0];
    const formData = new FormData();
    formData.append('file', file);

    fetch('http://localhost:5000/upload', {
      method: 'POST',
      body: formData,
    })
    .then((response) => response.json())
    .then((data) => {
      const fileUrl = data.fileUrl;

      // Send file URL as a message
      const chatTime = new Date().toTimeString().slice(0, 5);
      const fileMessageData = {
        sender: loggedInUser,
        receiver: selectedUser,
        message: fileUrl, // Message is the file URL
        chat_time: chatTime,
      };

      // Append the file message locally for the sender
      setMessages((prevMessages) => [...prevMessages, fileMessageData]);

      // Emit file message to the server
      socket.emit('sendMessage', fileMessageData);
    })
    .catch((err) => {
      console.error('Error uploading file:', err);
    });
};

const handleEditMessage = (messageId, currentMessage) => {
  const newMessage = prompt('Edit your message:', currentMessage);
  if (newMessage && newMessage.trim()) {
    socket.emit('editMessage', { id: messageId, newMessage, sender: loggedInUser });
  }
};

const handleDeleteMessage = (messageId) => {
  if (window.confirm(`Are you sure you want to delete the message with ID: ${messageId}?`)) {
    socket.emit('deleteMessage', { messageId, sender: loggedInUser });
  }
};

const filteredUsers = userList.filter((user) =>
  user.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
  (user.email && user.email.toLowerCase().includes(searchQuery.toLowerCase()))
);

return (
  <Container>
    {!loggedInUser ? (
      <div style={{ margin: 'auto', textAlign: 'center' }}>
        <h1>Login</h1>
        <input
          type="text"
          placeholder="Enter username"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          style={{
            padding: '10px',
            borderRadius: '20px',
            fontSize: '16px',
            marginBottom: '10px',
            outline: 'none',
            border: '1px solid #ccc',
          }}
        />
        <button
          onClick={handleLogin}
          style={{
            padding: '10px 20px',
            borderRadius: '20px',
            backgroundColor: '#25D366',
            color: '#fff',
            cursor: 'pointer',
            fontSize: '16px',
          }}
        >
          Login
        </button>
      </div>
    ) : (
      <>
        <UserListContainer>
          <UserName>
            <FontAwesomeIcon icon={faUserCircle} /> Logged in as: {loggedInUser}
          </UserName>

          <SearchContainer>
            <FontAwesomeIcon icon={faSearch} style={{ position: 'absolute', marginLeft: '15px', color: '#888' }} />
            <SearchInput
              type="text"
              placeholder="Search users..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </SearchContainer>

          <h3>Users</h3>
          {filteredUsers.length > 0 ? (
            filteredUsers
              .filter((user) => user.username !== loggedInUser)
              .map((user) => (
                <UserItem
                  key={user.username}
                  user={user}
                  isSelected={selectedUser === user.username}
                  onSelect={handleUserSelect}
                />
              ))
          ) : (
            <p>No users found</p>
          )}
        </UserListContainer>

        <ChatWindow>
          {selectedUser ? (
            <>
              <SelectedUserInfo>
                <strong>{selectedUser}</strong> - {selectedUserEmail}
                <br />
                <span style={{ color: userList.find((user) => user.username === selectedUser)?.status === 'online' ? 'green' : 'red' }}>
                  {userList.find((user) => user.username === selectedUser)?.status === 'online' ? 'Online' : 'Offline'}
                </span>
              </SelectedUserInfo>

              <MessageContainer>
              {messages.map((msg, index) => (
                <Message key={index} $isSender={msg.sender === loggedInUser}>
                  <strong>{msg.sender === loggedInUser ? 'You' : msg.sender}</strong>:
                  {msg.message.startsWith('http://localhost:5000/uploads/') ? (
                    <a href={msg.message} target="_blank" rel="noopener noreferrer">
                      Download File
                    </a>
                  ) : (
                    msg.message
                  )}
                  <Timestamp>{msg.chat_time} | {msg.id}</Timestamp>
                </Message>
              ))}


                {isTyping && (
                  <TypingIndicator>
                    <PulseLoader size={8} color="#128c7e" /> {selectedUser} is typing...
                  </TypingIndicator>
                )}

                <div ref={messagesEndRef} />
              </MessageContainer>

              <InputContainer>
                <Input
                  type="text"
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  onKeyDown={handleTyping}
                  placeholder="Type a message..."
                />
                <Button onClick={sendMessage}>
                  Send <FontAwesomeIcon icon={faPaperPlane} style={{ marginLeft: '5px' }} />
                </Button>
              </InputContainer>
            </>
          ) : (
            <div style={{ margin: 'auto', textAlign: 'center', color: '#888' }}>
              <h2>Select a user to start chatting</h2>
            </div>
          )}
        </ChatWindow>
      </>
    )}
  </Container>
);
}

// Component to render individual user items
const UserItem = ({ user, isSelected, onSelect }) => {
return (
  <div
    style={{
      padding: '10px',
      borderBottom: '1px solid #ddd',
      cursor: 'pointer',
      backgroundColor: isSelected ? '#ddd' : '#fff',
      display: 'flex',
      alignItems: 'center',
      position: 'relative',
    }}
    onClick={() => onSelect(user)}
  >
    <StatusIndicator icon={faCircle} status={user.status} /> {user.username}
  </div>
);
};

export default App;


// server.js

const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const mysql = require('mysql2');
const cors = require('cors');

const app = express();
app.use(cors());

// Create the server using HTTP
const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: 'http://localhost:3000', // Your React app URL
    methods: ['GET', 'POST'],
  },
});

// Connect to MySQL database
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'root',
  database: 'chatapp',
});

db.connect((err) => {
  if (err) throw err;
  console.log('Connected to MySQL Database');
});

// Store users and their statuses (online/offline)
let users = {};

io.on('connection', (socket) => {
  console.log('A user connected: ' + socket.id);

  // Event to check if the user exists and track their connection
  socket.on('checkUser', (username) => {
    const query = 'SELECT * FROM users WHERE username = ?';
    db.query(query, [username], (err, result) => {
      if (err) throw err;

      if (result.length > 0) {
        const user = result[0];
        // If user exists, store their status and socket ID
        users[username] = { socketId: socket.id, status: 'online' };
        console.log(`${username} logged in with socket ID: ${socket.id}`);

        // Fetch all users from the database
        db.query('SELECT * FROM users', (err, allUsers) => {
          if (err) throw err;

          // Map all users with their current status and email
          const updatedUsers = allUsers.map((user) => ({
            username: user.username,
            email: user.email, // Include email
            status: users[user.username]?.status || 'offline',
          }));

          // Emit the updated user list to all connected clients
          io.emit('updateUserList', updatedUsers);

          // Notify the client that the user exists
          socket.emit('userExists', true);
        });
      } else {
        // Notify the client that the user doesn't exist
        socket.emit('userExists', false);
      }
    });
  });

 // Event to handle chat messages between users
 socket.on('sendMessage', (data) => {
  const { sender, receiver, message } = data;

  // Get the current time in HH:MM format
  const chatTime = new Date().toTimeString().slice(0, 5);

  // Save message and chat_time to the database
  const query = 'INSERT INTO messages (sender, receiver, message, chat_time) VALUES (?, ?, ?, ?)';
  db.query(query, [sender, receiver, message, chatTime], (err) => {
    if (err) throw err;
    console.log(`Message from ${sender} to ${receiver} saved to database with chat_time ${chatTime}`);
  });

  // Send the message to the receiver if they are online
  if (users[receiver] && users[receiver].socketId) {
    const receiverSocketId = users[receiver].socketId;
    io.to(receiverSocketId).emit('receiveMessage', { sender, receiver, message, chat_time: chatTime });
  }
});

  // Event to fetch chat history
  socket.on('getChatHistory', ({ sender, receiver }) => {
    const query = 'SELECT sender, receiver, message, chat_time FROM messages WHERE (sender = ? AND receiver = ?) OR (sender = ? AND receiver = ?) ORDER BY chat_time';
    db.query(query, [sender, receiver, receiver, sender], (err, result) => {
      if (err) throw err;
  
      console.log('Chat history from database:', result); // Log result
      socket.emit('chatHistory', result);
    });
  });
  
  
  
  // Event to handle typing indicator
  socket.on('typing', ({ to, from }) => {
    if (users[to] && users[to].socketId) {
      const receiverSocketId = users[to].socketId;
      io.to(receiverSocketId).emit('userTyping', from);
    }
  });

  // Handle stop typing indicator
  socket.on('stopTyping', ({ to, from }) => {
    if (users[to] && users[to].socketId) {
      const receiverSocketId = users[to].socketId;
      io.to(receiverSocketId).emit('stopTyping', from);
    }
  });

  // Handle user disconnecting
  socket.on('disconnect', () => {
    let disconnectedUser;

    // Find which user disconnected based on the socket ID
    for (let [username, userInfo] of Object.entries(users)) {
      if (userInfo.socketId === socket.id) {
        disconnectedUser = username;
        break;
      }
    }

    // If a user was found, remove them from the users object
    if (disconnectedUser) {
      delete users[disconnectedUser];
      console.log(`User ${disconnectedUser} disconnected`);

      // Fetch all users from the database and update the user list
      db.query('SELECT * FROM users', (err, allUsers) => {
        if (err) throw err;

        // Map all users with their current status and email
        const updatedUsers = allUsers.map((user) => ({
          username: user.username,
          email: user.email, // Include email
          status: users[user.username]?.status || 'offline',
        }));

        // Emit the updated user list to all connected clients
        io.emit('updateUserList', updatedUsers);
      });
    }
  });
});

// Start the server on port 5000
server.listen(5000, () => {
  console.log('Server is running on port 5000');
});
